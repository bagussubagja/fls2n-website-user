<?php
$query_kj1 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '2'");
$query_kj2 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '3'");
$query_kj3 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '1'");
$query_kj4 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '5'");
$query_kj5 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '8'");
$query_kj6 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '9'");
$query_kj7 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '10'");
$query_kj8 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '16'");

$query_bd1 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '18'");
$query_bd2 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '15'");
$query_bd3 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '14'");
$query_bd4 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '13'");
$query_bd5 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '12'");
$query_bd6 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '11'");
$query_bd7 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '7'");
$query_bd8 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '6'");

$query_rek1 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '4'");
$query_rek2 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '17'");
$query_rek3 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '19'");
$query_rek4 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '20'");
$query_rek5 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '6'");
$query_rek6 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '7'");
$query_rek7 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '8'");
$query_rek8 = mysqli_query($connect, "SELECT * FROM movies WHERE id = '9'");

?>