<?php
$connect = mysqli_connect("az999-azure-mysql.mysql.database.azure.com", "septiangantenk@az999-azure-mysql", "zjv%$37EDo");

mysqli_select_db($connect, "database_fls2n_web") or die("Tidak dapat konek ke database");
